LAMI - Latent Model Interface


WHAT IS LAMI?

LAMI is an interface that allows users of the GENLAT and LATCLASS programs
to run their analyses more conveniently than using the original DOS programs
directly.


WHAT DOES LAMI DO EXACTLY?

GENLAT and LATCLASS require the input data files to have specific names and
that the input files are placed in the same folders as the programs them selves
(i.e. the respective program folders). LAMI on the other hand allows the user
to specify any data file (of the correct format) of any name in any directory to
be analysed. Once the user has specified the input file and the desired output
location, LAMI will rename the file as appropriate and copy it into the required
location. LAMI then instructs GENLAT or LATCLASS (as appropriate) to analyse the
data. Once the analysis is complete, LAMI will copy the results from the analysis 
into the user specified output location.

WARNING: LAMI will use the same directory as LAMI.EXE is installed into to
         manage files (i.e. the LAMI program folder). Any files placed manually 
         into this directory may therefore be overwritten or deleted by the program.
         The files that may be deleted are any files bearing the same names as
         the default GENLAT or LATCLASS input and output files (i.e. Lat.inp,
         Li7.out, Li8.out, Matrix.out, Fort.2, Latc.inp, Latc7.out, Latc8.out,
         Latc9.out, etas.out and pis.out). You have been warned - do not place
         any files other than the required *.exe files (i.e. Genlat.exe and
         Latclass.exe) into the LAMI program folder.
     
NOTE:    LAMI is completely independent program from GENLAT and LATCLASS.
         For the program to work, both GENLAT.EXE and LATCLASS.EXE need to be
         placed in the same folder as LAMI.EXE (which will be the case if the
         LAMI setup program has been used - see below).


HOW TO INSTALL LAMI

* Minimum Requirements:
  IBM Compatible PC 

  MS Windows 9x, NT 3.51 with Service Pack 5, or NT 4.0 or later.
  3MB free disk space 

* Installation:
  The LAMI setup program configures the program for your version of Windows.
  To install, copy the files from Lami.zip to a folder on your hard drive. 
  The folder should contain three files: Setup.exe, Lami.cab and Setup.lst.
  Run SETUP.EXE and follow the on-screen instructions.
 
  NOTE: Depending on the configuration of your system, using the setup program
        may not always be needed. In these cases, merely copying the LAMI.EXE,
        GENLAT.EXE and LATCLASS.EXE files into the same folder will be enough.
        Again, make sure the program folder does not include any GENLAT or
        LATCLASS data files (see warning above).
       

USING THE PROGRAM FOR THE FIRST TIME

LAMI utilizes external text editors to view datafiles and display results. When
using the program for the first time you need to specify which text editor you
want to use. To do so, from the 'Settings' menu select 'Text Editor'. This will
open the 'LAMI Settings' dialogue box. Press the '...' button to locate an 
executable of a text editor (for example "NOTEPAD.EXE" which is usually found 
in the "C:\WINDOWS" directory). Once the exe has been located press the 'Apply'
button and then 'Close'. Alternatively you may want to obtain a more
professionaltext editor such as TextPad (awailable from http://www.textpad.com/).

Once a text editor has been specified, one can use the 'View Input' and 
'View Output' buttons to open data files. LAMI will also use the text editor
to view GENLAT and LATCLASS results as they are produced.

NOTE: LAMI will not support word processors as text editors.


USING THE PROGRAM

* Use the tab buttons on the bottom of the LAMI form to select between GENLAT
  and LATCLASS. 
* To run analysis, use the Input File '...' button to locate your input file.
* In the output file box, either type the filename you want the results to be 
  written into (the file will then be saved into the same directory as the
  input file). Alternatively use the Output File '...' button to select an 
  already  existing output file you want to overwrite. This file may either 
  be in the same  directory as the input file or in a different directory.
* To run the analysis simply press the 'Run' button. This will start GENLAT or
  LATCLASS (whichever tab is selected) in a separate window which will close
  automatically when the analysis is completed.
* On the GENLAT form, one can tick to preserve the estimated parameter values
  in a separate file (LI8.OUT). If selected, then LI8.OUT will be saved into
  the same folder as the Input File. Note: The next time LAMI is run and this
  option is selected, LI8.OUT will be overwritten unless it is first renamed or 
  moved to another directory.
* By default, LAMI will always appear 'on top' of the screen. This is done so
  the program does not dissapear behind every program it is used to evoke.
  To temporarily make LAMI move back and forth on the screen like most other
  programs do, use the options on the 'Appearance' menu. LAMI will again appear
  'on top' the next time the program is started.
* For convenience, when an Input File has been specified in LAMI some details
  of the file will be shown on the form (like nubmer of cases and items etc.). 
  If the input file has been amended since loaded into LAMI one can press the 
  'Reload Input'  button to refresh the information displayed on the form.
  

FAQ

* LAMI appears frozen while analysis is being run.
  For large analyses LAMI will appear frozen but it isn't. Since LAMI, GENLAT
  and LATCLASS are completely independent programs, LAMI is instructed to wait
  and do absolutely nothing until either of the latent models has completed.
  Just wait until the analysis is complete.

* I'm unable to close LAMI once analysis has begun.
  Just close GENLAT or LATCLASS (whichever is running) and LAMI will come back
  to live.


LAMI Copyright (c) 2002 - O. Th. Gylfason
GENLAT Copyright (c) 2002 - I. Moustaki
LATCLASS Copyright (c) 2002 - D. Bartlolomew, L. deMenezes, M. Knott and P. Tzamourani

All Rights Reserved